<?php /* Smarty version 2.6.14, created on 2014-05-21 20:24:24
         compiled from practica/formulariRegistre.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['headPractica']; ?>



    <div class="header_form">
        <h1>SIGN UP!</h1>
        <p>All the fields marked with a <strong>*</strong> are required.</p>
    </div>

    <form name="signup_form" class="form" method="post" onsubmit="return validarRegistre();">

        <section>

            <label for="name">NAME <strong>*</strong>
                <?php if ($this->_tpl_vars['vNom']): ?><div class="notValid">&nbsp;&nbsp;&nbsp;<img class="img_notValid" src="<?php echo $this->_tpl_vars['url_creu']; ?>
"><p class="notValid">&nbsp;This name is already used!</p></div><?php endif; ?></label>
            <input name="newUser" id="name" type="text" class="input_form" <?php if (! $this->_tpl_vars['vNom'] && ! $this->_tpl_vars['vLogin'] && ! $this->_tpl_vars['vMail'] && ! $this->_tpl_vars['vPas']): ?> placeholder="NAME" <?php else: ?> value = "<?php echo $this->_tpl_vars['nom']; ?>
" <?php endif; ?> required/>


            <label for="login">LOGIN <strong>*</strong>
                <?php if ($this->_tpl_vars['vUsed']): ?><div class="notValid">&nbsp;&nbsp;&nbsp;<img class="img_notValid" src="<?php echo $this->_tpl_vars['url_creu']; ?>
"><p class="notValid">&nbsp;This login is already used!</p></div><?php endif; ?></label>
            <?php if ($this->_tpl_vars['vLogin']): ?><div class="notValid">&nbsp;&nbsp;&nbsp;<img class="img_notValid" src="<?php echo $this->_tpl_vars['url_creu']; ?>
"><p class="notValid">&nbsp;This login is incorrect (2 letters + 2 numbers)!</p></div><?php endif; ?></label>
            <input name="newLogin" id="login" type="text" class="input_form" <?php if (! $this->_tpl_vars['vNom'] && ! $this->_tpl_vars['vLogin'] && ! $this->_tpl_vars['vMail'] && ! $this->_tpl_vars['vPas']): ?> placeholder="LOGIN" <?php else: ?> value = "<?php echo $this->_tpl_vars['login']; ?>
" <?php endif; ?> required/>



            <label for="email">EMAIL <strong>*</strong>
                <?php if ($this->_tpl_vars['vMail']): ?><div class="notValid">&nbsp;&nbsp;&nbsp;<img class="img_notValid" src="<?php echo $this->_tpl_vars['url_creu']; ?>
"><p class="notValid">&nbsp;This email is not valid!</p></div><?php endif; ?></label>
            <input name="newEmail" id="email" type="email" class="input_form" <?php if (! $this->_tpl_vars['vNom'] && ! $this->_tpl_vars['vLogin'] && ! $this->_tpl_vars['vMail'] && ! $this->_tpl_vars['vPas']): ?> placeholder="example@dom.com" <?php else: ?> value = "<?php echo $this->_tpl_vars['email']; ?>
" <?php endif; ?> required/>


            <label for="Password">PASSWORD (6-20 characters) <strong>*</strong>
                <?php if ($this->_tpl_vars['vPas']): ?><div align="top" class="notValid">&nbsp;&nbsp;&nbsp;<img class="img_notValid" src="<?php echo $this->_tpl_vars['url_creu']; ?>
"><p class="notValid">&nbsp;Password must be between 6 and 20 characters long!</p></div><?php endif; ?></label>
            <input name="newPassword" id="Password" type="password" class="input_form" <?php if (! $this->_tpl_vars['vNom'] && ! $this->_tpl_vars['vLogin'] && ! $this->_tpl_vars['vMail'] && ! $this->_tpl_vars['vPas']): ?> placeholder="PASSWORD" <?php else: ?> value = "<?php echo $this->_tpl_vars['password']; ?>
" <?php endif; ?> required/>


            <div class="footer_form">
                <input type="submit" name="submit_button" value="SIGN UP" class="button_form" />
            </div>

        </section>

    </form>

    <a href="<?php echo $this->_tpl_vars['loginFacebookURL']; ?>
" class="btn btn-primary btn-block" type="button"><img  class="boto_fb" src="imag/signupFacebook.png"></a>



<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>