<?php /* Smarty version 2.6.14, created on 2014-05-20 17:45:44
         compiled from practica/myRatedReviews.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['headPractica']; ?>


    <?php echo $this->_tpl_vars['modules']['llistatMyRatedReviews']; ?>


<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>