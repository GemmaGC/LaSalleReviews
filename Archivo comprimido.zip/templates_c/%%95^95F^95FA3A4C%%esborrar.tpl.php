<?php /* Smarty version 2.6.14, created on 2014-03-31 15:51:42
         compiled from exercici4/esborrar.tpl */ ?>


<?php echo $this->_tpl_vars['modules']['head']; ?>


    <div class="go_back_container_micos">

        <a class="prev" href="<?php echo $this->_tpl_vars['enrere']; ?>
">Enrere</a>

    </div>

    <section>
        <img class = "esborrar" src="https://cdn3.iconfinder.com/data/icons/linecons-free-vector-icons-pack/32/like-512.png">
        <h1 class = "esborrar">Imatge esborrada amb èxit! :D</h1>
    </section>


<?php echo $this->_tpl_vars['modules']['footer']; ?>