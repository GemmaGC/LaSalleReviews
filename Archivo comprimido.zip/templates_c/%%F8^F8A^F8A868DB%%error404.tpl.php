<?php /* Smarty version 2.6.14, created on 2014-04-09 13:33:06
         compiled from error/error404.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['head']; ?>


    <p class="error"><img class="alert" src="<?php echo $this->_tpl_vars['url']['global']; ?>
/imag/alert.svg">    <strong>Ooops! Pàgina error 404.</strong><br/>Sembla que has intentat entrar en una pàgina que no existeix!</p>

<?php echo $this->_tpl_vars['modules']['footer']; ?>