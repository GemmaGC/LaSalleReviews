<?php /* Smarty version 2.6.14, created on 2014-03-31 15:45:59
         compiled from shared/head.tpl */ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<!--
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="title" content="" /> 
		-->
		<meta name="robots" content="all" />
		<!--
		<meta name="expires" content="never" />
		<meta name="distribution" content="world" />
		-->
		<title>PROJECTES WEB</title>
		<!--<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['global']; ?>
/css/style.css">-->
        <link rel="stylesheet" href="<?php echo $this->_tpl_vars['css']; ?>
">
	</head>

	<body>
		<div class="main_header">
			<header>
				<!--<div class="site-logo"><?php echo $this->_tpl_vars['header']; ?>
</div>-->
				<div class="site-logo">PROJECTES WEB</div>
			</header>
		</div>
		
		<div id="wrapper">