<?php /* Smarty version 2.6.14, created on 2014-03-31 15:45:59
         compiled from shared/footer.tpl */ ?>
		</div>
		<footer>
			<p>La Salle - Universitat Ramon Llull - curs 2013 / 2014</p>
		</footer>

		<script src="<?php echo $this->_tpl_vars['url']['global']; ?>
/js/scripts.js"></script>
	</body>
</html>