<?php /* Smarty version 2.6.14, created on 2014-05-21 10:33:42
         compiled from practica/llistatImatges.tpl */ ?>


    <div class="Last10Images">

        <h1>LAST 10 IMAGES</h1>
        <?php $_from = $this->_tpl_vars['reviews']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['r']):
?>

            <img class="section_last_img" src="/imag/img_usuaris/100_<?php echo $this->_tpl_vars['r']['image']; ?>
">

           
            <!--<img class="section_last_img" src='imag/img_usuaris/704_'>-->

        <?php endforeach; endif; unset($_from); ?>
    </div>