<?php /* Smarty version 2.6.14, created on 2014-05-21 10:16:27
         compiled from practica/noResults.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['headPractica']; ?>


    <div class="noResultsPage">
        <h3><?php echo $this->_tpl_vars['missatge']; ?>
</h3>
    </div>

<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>