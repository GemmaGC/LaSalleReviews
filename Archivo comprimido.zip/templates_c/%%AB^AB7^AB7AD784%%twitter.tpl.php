<?php /* Smarty version 2.6.14, created on 2014-05-15 11:36:55
         compiled from practica/twitter.tpl */ ?>
<?php echo '

    <a class="twitter-timeline" id="twitterBlock" href="https://twitter.com/search?q=%23projectesWeb14" data-widget-id="455734456284753920">Tweets about "#projectesWeb14"</a>
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?\'http\':\'https\';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>



'; ?>