<?php /* Smarty version 2.6.14, created on 2014-05-10 16:29:59
         compiled from practica/error/errorP403.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['headPractica']; ?>


    <div class="error">
        <div class="bloc_error_403">ACCESS DENIED.</div>
        <p><strong>Ooops! Error 403.</strong><br/>Sorry but you are not authorized to access this page.</p>
    </div>

    <div class="omplir"></div>

<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>