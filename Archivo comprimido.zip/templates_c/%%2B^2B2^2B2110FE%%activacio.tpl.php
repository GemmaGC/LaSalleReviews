<?php /* Smarty version 2.6.14, created on 2014-05-06 11:23:10
         compiled from practica/activacio.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['headPractica']; ?>



        <p class="text_activa">Click on the link to activate your account:
        <form><input type="submit" name="codi_activacio" value="<?php echo $this->_tpl_vars['codi']; ?>
" class="linkActiva"/></form></p>

<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>