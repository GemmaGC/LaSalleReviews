<?php /* Smarty version 2.6.14, created on 2014-05-21 10:19:41
         compiled from practica/formulariLogin.tpl */ ?>

<?php echo $this->_tpl_vars['modules']['headPractica']; ?>



            <div class="header_form">
                <h1>LOG IN!</h1>
                <p>All the fields marked with a <strong>*</strong> are required.</p>
            </div>

            <?php if (( ! $this->_tpl_vars['ok'] )): ?><p class="error_login"><?php echo $this->_tpl_vars['error']; ?>
</p><?php endif; ?>

            <form name="signup_form" class="form" method="post" onsubmit="return validarLogIn();">

                <div class="content_form">

                    <label for="email">EMAIL <strong>*</strong></label>
                    <input name="email" id="email" type="email" class="input_form" placeholder="example@dom.com" value="<?php echo $this->_tpl_vars['mail']; ?>
" required/>

		            <label for="Password">PASSWORD <strong>*</strong></label>
		            <input name="password" id="Password" type="password" class="input_form" placeholder="PASSWORD" required/>

                    <div class="footer_form">
                        <input type="submit" name="submit_button" value="LOG IN" class="button_form"/>
                    </div>

                </div>



		    </form>

            <a href="<?php echo $this->_tpl_vars['loginFacebookURL']; ?>
" class="btn btn-primary btn-block" type="button"><img class="boto_fb" src="imag/LoginFacebook.png"></a>
<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>