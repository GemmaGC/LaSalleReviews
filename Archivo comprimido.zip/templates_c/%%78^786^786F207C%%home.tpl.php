<?php /* Smarty version 2.6.14, created on 2014-05-21 14:55:00
         compiled from practica/home.tpl */ ?>


<?php echo $this->_tpl_vars['modules']['headPractica']; ?>


    <nav class="menu_lateral_fixe_home">
        <ul>
            <li>HOME SECTIONS >> &nbsp;&nbsp;&nbsp;</li>
            <li><a href="#Best_Review">BEST REVIEW</a></li>
            <li class="sep">|</li>
            <li><a href="#Reviews_Lists">LAST 10 REVIEWS & IMAGES</a></li>
            <li class="sep">|</li>
            <li><a href="#10_Best_Reviews">10 BEST RATED REVIEWS</a></li>
            <li class="sep">|</li>
            <li><a href="#Block_Twitter">TWITTER</a></li>
        </ul>
    </nav>

    <section id="Best_Review">
        <?php echo $this->_tpl_vars['modules']['bestReview']; ?>

    </section>

    <section class="llistats" id="Reviews_Lists">
        <?php echo $this->_tpl_vars['modules']['llistatReviews']; ?>

        <?php echo $this->_tpl_vars['modules']['llistatImatges']; ?>

    </section>

    <div class="separator" id="10_Best_Reviews"></div>

    <section>
        <?php echo $this->_tpl_vars['modules']['llistatBestReviewsPuntuacio']; ?>

    </section>

    <div class="separator" id="Block_Twitter"></div>

    <?php echo $this->_tpl_vars['modules']['twitter']; ?>


<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>