<?php /* Smarty version 2.6.14, created on 2014-05-15 11:36:16
         compiled from practica/error/errorP404.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['headPractica']; ?>


    <div class="error">
        <img src="<?php echo $this->_tpl_vars['url']['global']; ?>
/imag/404.jpg">
        <p><strong>OOOPS! ERROR 404.</strong><br/>
            The page you are trying to reach does not exist, or has been moved. <br/>
            Please use the menus or the search box to find what you are looking for.
        </p>
    </div>


<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>