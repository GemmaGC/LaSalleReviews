<?php /* Smarty version 2.6.14, created on 2014-05-21 10:06:02
         compiled from practica/shared/footer.tpl */ ?>
        </div>

        <footer>
            <p class="footer_components">LA SALLE REVIEW.</p >
            <p class="footer_components">Designed by Ylenia, Claudia &amp; Gemma</p>
            <p class="footer_love">Made with ♥ in Barcelona.</p>

        </footer>

        <?php echo '
            <script>
                tinymce.init({selector:\'textarea\'});
            </script>

        '; ?>



    </body>
</html>