<?php /* Smarty version 2.6.14, created on 2014-05-21 19:45:51
         compiled from practica/duesOpcions.tpl */ ?>
<?php echo $this->_tpl_vars['modules']['headPractica']; ?>

        <div class="welcome_title">
            <h1><?php echo $this->_tpl_vars['title']; ?>
</h1>
        </div>

        <p class="welcome_info"><?php echo $this->_tpl_vars['subtitle']; ?>
</p>

        <div class="welcome_buttons_container">
            <?php if ($this->_tpl_vars['esborrar']): ?>

                <!--<a href="/deleteReview" class="welcome_button">YES</a>-->
                <form method='post' action='/deleteReview'><input type="submit" name="YES" class="welcome_button" value="YES" /></form>
                <a href="<?php echo $this->_tpl_vars['url']['global']; ?>
/myReviews" class="welcome_button">NO</a>
            <?php else: ?>
                <a href="<?php echo $this->_tpl_vars['url']['global']; ?>
/LaSalleReview" class="welcome_button">HOME</a>
                <?php if ($this->_tpl_vars['log'] == 0 && $this->_tpl_vars['send'] == 1): ?>
        <!--CAL ARREGLAR EL RESEND DEL FORM AMB L'ACTION-->
                    <form method='post' action=''><input type="submit" name="codi_activacio" class="welcome_button arreglo_welcome_button" value="RE-SEND" /></form>
                <?php elseif ($this->_tpl_vars['log'] == 0): ?>
                    <a href="<?php echo $this->_tpl_vars['url']['global']; ?>
/logIn" class="welcome_button">LOG IN</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
<?php echo $this->_tpl_vars['modules']['footerPractica']; ?>