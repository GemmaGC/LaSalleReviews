<?php
class Exercici3FormulariMarmotaController extends Controller
{

    public function build( )
    {
        $this->setLayout( 'exercici3/formulari_marmota.tpl' );
    }
}