<?php

class SharedFooterController extends Controller
{
	public function build( )
	{
		$this->setLayout( 'shared/footer.tpl' );
	}
}


?>
