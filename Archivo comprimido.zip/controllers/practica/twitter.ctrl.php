<?php

class PracticaTwitterController extends Controller {

    protected $view = 'practica/twitter.tpl';


    public function build( ){
        $this->setLayout( $this->view );

    }
}

