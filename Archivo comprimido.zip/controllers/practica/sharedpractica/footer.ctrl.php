<?php

class SharedpracticaFooterController extends Controller
{

    public function build( )
    {
        $this->setLayout( 'practica/shared/footer.tpl' );
    }
}


?>

